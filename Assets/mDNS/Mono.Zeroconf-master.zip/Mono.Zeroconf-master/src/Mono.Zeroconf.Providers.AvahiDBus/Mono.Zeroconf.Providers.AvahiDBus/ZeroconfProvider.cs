//
// ZeroconfProvider.cs
//
// Author:
//   Aaron Bockover <abockover@novell.com>
//
// Copyright (C) 2007-2008 Novell, Inc.
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections;

[assembly:Mono.Zeroconf.Providers.ZeroconfProvider (typeof (Mono.Zeroconf.Providers.AvahiDBus.ZeroconfProvider))]

namespace Mono.Zeroconf.Providers.AvahiDBus
{
    public class ZeroconfProvider : IZeroconfProvider
    {
        public void Initialize ()
        {
            DBusManager.Initialize ();
        }
        
        public Type ServiceBrowser { 
            get { return typeof (Mono.Zeroconf.Providers.AvahiDBus.ServiceBrowser); }
        }
        
        public Type RegisterService { 
            get { return typeof (Mono.Zeroconf.Providers.AvahiDBus.RegisterService); }
        }
        
        public Type TxtRecord {
            get { return typeof (Mono.Zeroconf.Providers.AvahiDBus.TxtRecord); }
        }
    }
}
